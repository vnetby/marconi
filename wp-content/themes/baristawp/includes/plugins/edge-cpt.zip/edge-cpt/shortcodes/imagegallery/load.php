<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/imagegallery/image-gallery.php';