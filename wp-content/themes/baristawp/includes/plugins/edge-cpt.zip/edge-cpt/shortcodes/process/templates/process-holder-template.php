<div <?php barista_edge_class_attribute($holder_classes); ?>>
	<div class="edgtf-process-inner clearfix">
		<?php echo do_shortcode($content); ?>
	</div>
</div>