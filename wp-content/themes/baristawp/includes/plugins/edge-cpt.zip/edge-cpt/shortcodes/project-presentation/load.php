<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/project-presentation/project-presentation.php';