<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/banner/banner.php';
