<?php

require_once EDGE_CORE_ABS_PATH . '/shortcodes/accordions/accordion.php';
require_once EDGE_CORE_ABS_PATH . '/shortcodes/accordions/accordion-tab.php';
require_once EDGE_CORE_ABS_PATH . '/shortcodes/accordions/custom-styles/custom-styles.php';
require_once EDGE_CORE_ABS_PATH . '/shortcodes/accordions/options-map/map.php';
