<?php
/**
 * Counter shortcode template
 */
?>
<div class="edgtf-countdown" id="countdown<?php echo esc_html($id); ?>" <?php echo barista_edge_get_inline_attrs($countdown_data) ?>></div>