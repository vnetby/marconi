<div class="edgtf-accordion-holder clearfix <?php echo esc_attr($acc_class)?> ">
	<?php echo do_shortcode($content); ?>
</div>